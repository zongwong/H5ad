.logo {
  position: absolute;
  left: -1000px;
  top: -1000px;
}
.share {
  position: absolute;
  width: 100%;
  height: 100%;
  display: none;
  z-index: 2;
}
.share img {
  position: absolute;
}
.share .sharepng {
  width: 100%;
  height: 100%;
  top: 0px;
  left: 0px;
}
.game {
  position: absolute;
  width: 100%;
  height: 100%;
}
