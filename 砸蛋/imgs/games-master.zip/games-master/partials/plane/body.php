<div class="logo">
  <img src="http://game.webxinxin.com/plane/assets/logo.jpg" alt="" />
</div>
<div id="share" class="share">
  <img class="sharepng" src="http://game.webxinxin.com/plane/assets/share.png" alt="" />
  <img class="closebtn" src="http://game.webxinxin.com/plane/assets/close.png" alt="" onclick="onCloseShare();" />
</div>
<div id="game" class="game"></div>
