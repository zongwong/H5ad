<div class="logo">
  <img id="logo" src="" alt="" />
</div>
<div id="share" class="share">
  <img class="sharepng" src="http://game.webxinxin.com/weiduan/assets/share.jpg" alt="" />
</div>
<div id="game" class="game"></div>
