<script>
var TITLE = "【爆笑】这真是亲老婆，哈哈！";
var LOGO = "http://game.webxinxin.com/weiduan/assets/logo_2.jpg";
var PERSONS = [
    "weiduan_2_me",
    "weiduan_2_1"
  ];
var GSENS = [{
    name: 'weiduan_2_1',
    str: '老婆，跟你说个事儿呗',
    me: false,
    time: 4
  }, {
    name: 'weiduan_2_me',
    str: '啥事啊？宝贝',
    me: true,
    time: 3
  }, {
    name: 'weiduan_2_1',
    str: '我今天去上班，路上不 小心',
    me: false,
    time: 5
  }, {
    name: 'weiduan_2_me',
    str: '然后呢？',
    me: true,
    time: 3
  }, {
    name: 'weiduan_2_1',
    str: '新买的自行车被我撞散 架了',
    me: false,
    time: 5
  }, {
    name: 'weiduan_2_me',
    str: '老公没事的，你若安好 便是晴天',
    me: true,
    time: 4
  }, {
    name: 'weiduan_2_1',
    str: '老婆真好！',
    me: false,
    time: 4
  }, {
    name: 'weiduan_2_me',
    str: '安不好我弄死你！！',
    me: true,
    time: 5
  }, {
    name: 'weiduan_2_1',
    str: '。。。呜呜~~',
    me: false,
    time: 5
  }];
</script>