<script>
var TITLE = "【爆笑】你好，你是程序猿吗？";
var LOGO = "http://game.webxinxin.com/weiduan/assets/logo.jpg";
var PERSONS = [
    "weiduan_1_me",
    "weiduan_1_me_2",
    "weiduan_1_1"
  ];
var GSENS = [{
    name: 'weiduan_1_1',
    str: '你好，你是程序猿吗？',
    me: false,
    time: 4
  }, {
    name: 'weiduan_1_me',
    str: '你好，是的，请问你有 什么需求？',
    me: true,
    time: 3
  }, {
    name: 'weiduan_1_1',
    str: '我们公司想做个App，要 高端大气上档次，我们的 预算比较高，1000左右',
    me: false,
    time: 5
  }, {
    name: 'weiduan_1_me',
    str: '你刚才问什么？',
    me: true,
    time: 3
  }, {
    name: 'weiduan_1_1',
    str: '我们公司想做个App，要 高端大气上档次，预算 1000左右',
    me: false,
    time: 3
  }, {
    name: 'weiduan_1_me',
    str: '不是这句，是前面一句',
    me: true,
    time: 4
  }, {
    name: 'weiduan_1_1',
    str: '你好，你是程序猿吗？',
    me: false,
    time: 2
  }, {
    name: 'weiduan_1_me_2',
    str: '不是',
    me: true,
    time: 2
  }, {
    name: 'weiduan_1_1',
    str: '。。。',
    me: false,
    time: 5
  }];
</script>