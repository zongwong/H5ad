// tile的宽和高
var TILE_WIDTH = 16;
var TILE_HEIGHT = 16;

// 每一关敌人的数量
var ENEMY_NUMBER = 20;

// 总关数
var TOTAL_LEVEL = 15;

// 从哪一关开始
var START_LEVEL = 1;

// 产生奖品的概率
var BOUNS_PERCENT = 0.5;